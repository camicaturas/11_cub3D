/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   debug_tools.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybazylbe <ybazylbe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/08 17:14:37 by cberneri          #+#    #+#             */
/*   Updated: 2025/08/04 12:06:08 by ybazylbe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../cube3d.h"

void	print_map_on_console(t_struct *game_struct)
{
	int	y;

	if (!game_struct->minimap.map || !game_struct->minimap.map)
	{
		printf("ERROR: map_struct or map_struct->map is NULL\n");
		return ;
	}
	y = 0;
	while (game_struct->minimap.map[y])
	{
		printf("%s", game_struct->minimap.map[y]);
		y++;
	}
}

void	player_current_grid_pos(t_minimap *map)
{
	printf("Player is in grid cell: (%d, %d)\n",
		map->player_grid_x, map->player_grid_y);
}

void	get_player_center(t_struct *game_struct, int *x, int *y)
{
	*x = game_struct->player.pos.x * MINIMAP_TILE_SIZE
		+ MINIMAP_PLAYER_SIZE / 2;
	*y = game_struct->player.pos.y * MINIMAP_TILE_SIZE
		+ MINIMAP_PLAYER_SIZE / 2;
}

void	draw_line_segment(t_struct *game_struct, int center_x, int center_y,
		double radians)
{
	int	i;
	int	px;
	int	py;

	i = -1;
	while (++i < 100)
	{
		px = center_x + cos(radians) * i;
		py = center_y + sin(radians) * i;
		if (px >= 0
			&& px < game_struct->minimap.map_width * MINIMAP_TILE_SIZE
			&& py >= 0
			&& py < game_struct->minimap.map_height * MINIMAP_TILE_SIZE)
		{
			mlx_put_pixel(game_struct->minimap_img, px, py, GREEN);
		}
	}
}

void	draw_debug_green_line_direction(t_struct *game_struct)
{
	int		center_x;
	int		center_y;
	double	radians;

	get_player_center(game_struct, &center_x, &center_y);
	radians = game_struct->player.radians;
	draw_line_segment(game_struct, center_x, center_y, radians);
}
