/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   texture_utils2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybazylbe <ybazylbe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 11:49:37 by ybazylbe          #+#    #+#             */
/*   Updated: 2025/08/04 11:54:52 by ybazylbe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../cube3d.h"

mlx_texture_t	*get_vertical_texture(t_struct *game_struct)
{
	return (validate_and_get_north_south(game_struct));
}

mlx_texture_t	*get_texture(t_struct *game_struct, int hit_type)
{
	if (!game_struct->ray)
	{
		ft_putstr_fd("Error: game_struct->ray is NULL\n", 2);
		exit(1);
	}
	game_struct->ray->ray_angle
		= normalize_angle(game_struct->ray->ray_angle);
	if (hit_type == 0)
		return (get_horizontal_texture(game_struct));
	else
		return (get_vertical_texture(game_struct));
}

static double	calculate_vertical_offset(t_struct *game_struct,
	mlx_texture_t *texture)
{
	return ((int)fmodf((game_struct->ray->intersect_vert_y
				* (texture->width / TILE_SIZE)), texture->width));
}

static double	calculate_horizontal_offset(t_struct *game_struct,
	mlx_texture_t *texture)
{
	return ((int)fmodf((game_struct->ray->intersect_horz_x
				* (texture->width / TILE_SIZE)), texture->width));
}

double	get_texture_x_offset(t_struct *game_struct, mlx_texture_t *texture)
{
	if (game_struct->ray->is_active != 1)
		return (calculate_vertical_offset(game_struct, texture));
	else
		return (calculate_horizontal_offset(game_struct, texture));
}
