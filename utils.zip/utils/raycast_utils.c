/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycast_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybazylbe <ybazylbe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/06/08 17:14:37 by cberneri          #+#    #+#             */
/*   Updated: 2025/08/04 11:38:12 by ybazylbe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../cube3d.h"

static void	dda_draw_loop(t_struct *game, int steps, t_dda_params params)
{
	int	i;

	i = 0;
	while (i < steps)
	{
		if (params.x >= 0 && params.y >= 0
			&& params.x < game->minimap.map_width * MINIMAP_TILE_SIZE
			&& params.y < game->minimap.map_height * MINIMAP_TILE_SIZE)
		{
			mlx_put_pixel(game->minimap_img, (int)params.x,
				(int)params.y, GREEN);
		}
		params.x += params.x_inc;
		params.y += params.y_inc;
		i++;
	}
}

static void	dda_draw_line(t_struct *game, t_line_params line)
{
	int				dx;
	int				dy;
	int				steps;
	t_dda_params	params;

	dx = line.end_x - line.start_x;
	dy = line.end_y - line.start_y;
	steps = (int)fmax(fabs((double)dx), fabs((double)dy));
	if (steps == 0)
		return ;
	params.x = line.start_x;
	params.y = line.start_y;
	params.x_inc = dx / (double)steps;
	params.y_inc = dy / (double)steps;
	dda_draw_loop(game, steps, params);
}

static void	init_ray_params(t_struct *game_struct, double *player_angle,
	double *fov, int *num_rays)
{
	*player_angle = game_struct->player.radians;
	*fov = 60 * (M_PI / 180.0);
	*num_rays = 100;
}

void	draw_all_green_rays(t_struct *game_struct)
{
	double	player_angle;
	double	fov;
	int		num_rays;
	double	angle_step;

	init_ray_params(game_struct, &player_angle, &fov, &num_rays);
	angle_step = fov / num_rays;
	draw_rays_loop(game_struct, player_angle, fov, angle_step, num_rays);
}
