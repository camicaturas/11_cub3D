/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   raycast_utils2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybazylbe <ybazylbe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 11:36:49 by ybazylbe          #+#    #+#             */
/*   Updated: 2025/08/04 11:38:25 by ybazylbe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../cube3d.h"

static void	draw_rays_loop(t_struct *game_struct, t_ray_config config)
{
	double	start_angle;
	double	ray_angle;
	int		i;

	start_angle = player_angle - (fov / 2);
	i = 0;
	while (i < num_rays)
	{
		ray_angle = start_angle + i * angle_step;
		draw_green_ray(game_struct, ray_angle);
		i++;
	}
}

void	draw_rays_on_minimap(t_struct *game, t_ray ray)
{
	t_line_params	line;

	line.start_x = game->player.pos.x * MINIMAP_TILE_SIZE;
	line.start_y = game->player.pos.y * MINIMAP_TILE_SIZE;
	line.end_x = ray.hit_x * MINIMAP_TILE_SIZE;
	line.end_y = ray.hit_y * MINIMAP_TILE_SIZE;
	dda_draw_line(game, line);
}
