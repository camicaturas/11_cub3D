/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   texture_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ybazylbe <ybazylbe@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 11:44:54 by ybazylbe          #+#    #+#             */
/*   Updated: 2025/08/04 11:54:33 by ybazylbe         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../cube3d.h"

uint32_t	rgb_to_hex(char *rgb_str)
{
	int		r;
	int		g;
	int		b;
	char	*end;

	r = strtol(rgb_str, &end, 10);
	if (*end != ',')
		return (0x0);
	g = strtol(end + 1, &end, 10);
	if (*end != ',')
		return (0x0);
	b = strtol(end + 1, NULL, 10);
	return (((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF));
}

static mlx_texture_t	*validate_and_get_west_east(t_struct *game_struct)
{
	if (game_struct->ray->ray_angle > PI / 2
		&& game_struct->ray->ray_angle < 3 * (PI / 2))
	{
		if (!game_struct->texture.west)
		{
			ft_putstr_fd("Error: West texture is NULL\n", 2);
			exit(1);
		}
		return (game_struct->texture.west);
	}
	else
	{
		if (!game_struct->texture.east)
		{
			ft_putstr_fd("Error: East texture is NULL\n", 2);
			exit(1);
		}
		return (game_struct->texture.east);
	}
}

mlx_texture_t	*get_horizontal_texture(t_struct *game_struct)
{
	return (validate_and_get_west_east(game_struct));
}

static mlx_texture_t	*validate_and_get_north_south(t_struct *game_struct)
{
	if (game_struct->ray->ray_angle > 0
		&& game_struct->ray->ray_angle < PI)
	{
		if (!game_struct->texture.south)
		{
			ft_putstr_fd("Error: South texture is NULL\n", 2);
			exit(1);
		}
		return (game_struct->texture.south);
	}
	else
	{
		if (!game_struct->texture.north)
		{
			ft_putstr_fd("Error: North texture is NULL\n", 2);
			exit(1);
		}
		return (game_struct->texture.north);
	}
}
